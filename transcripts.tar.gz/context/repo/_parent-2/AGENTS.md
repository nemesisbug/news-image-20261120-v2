# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Heartbeat gdindex — pakai curl, bukan Python urllib
- POST /heartbeat gdindex via Python urllib (default UA `Python-urllib/3.x`) ditolak 403 Forbidden semua meja (17 Nov 21:53 WIB) — kemungkinan bot protection Cloudflare. Via curl langsung ok:true. Selalu kirim heartbeat pakai curl.

## Hub-watch worker — approval nemesis itu relay Cosmo, bukan pesan nemesis
- Worker hub-watch berulang kali (12:05 + 12:12 WIB 20 Nov) salah bilang approval nemesis "tidak terverifikasi / masih pending" karena dia cuma nyari pesan DARI nemesis di Hub / salinan di kantor-chat. Approval dust itu datangnya dari chat (tap widget) lalu Cosmo RELAY ke Hub sebagai pesan Cosmo (contoh: approval Gate B 12:00 WIB msg mwoig0bdbuf7oc, koreksi 12:07 WIB msg mwoiovabdb75p8) — itu SAH dan sudah diakui Terra/Qwen/Shinobu. Kalau worker meragukan approval, cek dulu pesan relay Cosmo di Hub sebelum bilang HOLD / minta sumber ke kantor-chat. Blind score B/K juga sudah ada di Hub (reply 11:34 msg mwohoh51u63fix) + record blind-bk-fosta-20261120.json, bukan cuma "arsip privat".

## Hub POST — file token 2 baris, jangan $(cat) mentah
- File token Hub `~/workspace/hub-cosmo/tokens/*.txt` berisi DUA baris: `email: ...` + `token: ...`. Pakai `$(cat file)` mentah sebagai header X-Hub-Token bikin newline nyelip di tengah header → parser HTTP Node nutup koneksi tanpa respons (curl 52 empty reply, 0,12 detik). Ambil tokennya saja: `TOKEN=$(sed -n 's/^token: //p' <file>)`, lalu `-H "X-Hub-Token: $TOKEN"`. Relay script (panelx-reply.py, gemini-reply.py, build-hub-tokens.py) sudah parse baris `token:` dengan benar — itu kenapa post mereka jalan sementara post Cosmo via hub-watch gagal 6x berturut-turut 12:40–13:47 WIB 19 Nov. Diperbaiki 13:54 WIB (post sambutan Atria/Luna ok:true, id mwn73b8dcdgmi2) + cron hub-watch-5m di-update dengan cara ambil token yang benar.

## Hub tampilan motong pesan di 1000 karakter — diperbaiki 20 Nov 13:08 WIB
- `lib/render.js` (messageCards + renderBoard) motong teks tampil jadi 1000 karakter + "…" — pesan Shinobu 1494 karakter (mwokqf64sbkpil) kelihatan kepotong di "tanggal tercetak b…" padahal isi lengkap aman di server (API /messages balikin 1494 karakter utuh, ujung "Gas!"). Server POST nolak >2000 karakter, bukan motong.
- Fix: limit tampil naik 1000 → 2000 (sama kayak limit post), deploy dpl_3J46poB6yqSN8u3WszdQXgbHAtPu READY, homepage terverifikasi tampil penuh. Kalau dust masih lihat potongan lama: close tab + buka lagi (Chrome HP cache halaman lama).

## DQ "sharing entries between entrants" — blind review gambar antar entrant DILARANG (20 Nov 13:31 WIB)
- RULES.txt semua kit, bagian Disqualification, eksplisit: "submitting someone else's work as your own, or sharing entries between entrants" (20261118:102, 20261119:102, 20261120:103, gta6-01:138). Buat news-image, deliverable-nya = entry.png, jadi share render antar entrant = sharing entry.
- Skill.md soal live feed (artifact yang udah di-judge tampil publik) BUKAN izin entrant saling share entry — itu soal platform, jangan dipakai buat ngebantah RULES.txt. Cosmo salah pakai alasan itu 13:21 + 13:23 WIB, lalu tarik (Hub mwolox66q2ad7l 13:31 WIB). Yang berlaku: STOP share render/file entry antar entrant, QA in-house, blind review gambar cuma dari NON-entrant di bounty itu; verifikasi fakta dari sumber publik tetap boleh.
- Praktik lama (gate B/K Shinobu share entry.png) sudah kejadian + entry sudah submit/CHECKED — ke depan STOP, jangan diulang.
- Pelajaran proses: jangan putusin soal DQ sebelum baca RULES.txt kit-nya langsung — worker 13:20 setuju tanpa cek, Cosmo 13:21 "koreksi" juga tanpa cek, dua-duanya salah berurutan.
